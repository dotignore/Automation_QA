package corejava.enumeration;

/**
 * Created by Maor on 5/22/2018.
 */

    public enum UserStatus {
        PENDING,
        ACTIVE,
        INACTIVE,
        DELETED;
    }

