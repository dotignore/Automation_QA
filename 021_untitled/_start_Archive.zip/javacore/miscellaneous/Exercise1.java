package corejava.miscellaneous;

/**
 * Created by Maor on 5/22/2018.
 * Java Exercise 1: Run a Java Application
 */

public class Exercise1 {

    // To generate main Type "psvm" and press Tab
    public static void main(String[] args) {
        System.out.println("Exercise1 executed");
    }
}
