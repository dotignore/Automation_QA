package corejava.miscellaneous;

/**
 * Created by Maor on 5/22/2018.
 * Java Exercise 2: Add Numbers
 */
public class Exercise2 {

    // To generate main Type "psvm" and press Tab
    public static void main(String[] args) {

        int num1 = 1;
        int num2 = 2;
        int result = num1 + num2;
        System.out.println("Result: " + result);
    }
}
