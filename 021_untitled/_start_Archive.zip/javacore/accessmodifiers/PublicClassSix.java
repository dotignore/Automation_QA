package corejava.accessmodifiers;

/**
 * Created by Maor on 5/25/2018.
 */
public class PublicClassSix {

    public int myMethod(int x){
        return x;
    }
}
