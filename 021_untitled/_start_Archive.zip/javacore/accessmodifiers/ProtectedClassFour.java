package corejava.accessmodifiers;

/**
 * Created by Maor on 5/25/2018.
 */
public class ProtectedClassFour {

    protected int myMethod(int a){
        return a;
    }
}
