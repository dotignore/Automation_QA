package corejava.arrays;

/**
 * Created by Maor on 5/26/2018.
 */

public class ArrayClass1 {

    public static void main(String[] args){

        int[] arr = new int[5];
        arr[0] = 11;
        arr[1] = 22;
        arr[2] = 33;
        arr[3] = 44;
        arr[4] = 55;

        System.out.println(arr[0]);
        System.out.println(arr[1]);
        System.out.println(arr[2]);
        System.out.println(arr[3]);
        System.out.println(arr[4]);

    }
}
