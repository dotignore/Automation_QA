package corejava.arrays;

/**
 * Created by Maor on 5/26/2018.
 */

public class Array2DClass {

        public static void main (String [] args){

            int[][] arr= {
                    {11, 22, 33},
                    {44, 55, 66}
            };

            System.out.println(arr[0][0]);
            System.out.println(arr[0][1]);
            System.out.println(arr[0][2]);
            System.out.println(arr[1][0]);
            System.out.println(arr[1][1]);
            System.out.println(arr[1][2]);

        }
}
