package corejava.arrays;

/**
 * Created by Maor on 6/4/2018.
 */

// Finding Length of Array:
public class ArrayLength {

    public static void main(String[] args){

        // Create an array of size 5 integers
        int[] arr = new int[50];

        // 'length' is a function in Java which gives you the size of an array
        System.out.println(arr.length);

    }
}
