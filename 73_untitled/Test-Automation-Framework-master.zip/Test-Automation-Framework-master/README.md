# Test-Automation-Framework
my first test automation framework 
 
 # Technolgy-Used:
 
 - Maven
 - TestNG
 - BDD
 - DDT
 - POM
 - Java
 - Selinume Web Driver
 - Headless
 - Support multiple browsers
 - Using Data Driven to read from Excel sheet, csv File, Jason File and Properties File                              
