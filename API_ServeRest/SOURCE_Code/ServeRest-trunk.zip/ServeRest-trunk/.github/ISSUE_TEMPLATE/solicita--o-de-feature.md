---
name: Solicitação de feature
about: Sugira uma melhoria que sentiu falta no ServeRest
title: ''
labels: enhancement, new issue
assignees: ''

---

**Sua solicitação de recurso está relacionada a um problema? Por favor descreva.**
Uma descrição clara e concisa de qual é o problema. Ex. Fico sempre frustrado quando [...]

**Descreva a solução que você deseja**
Uma descrição clara e concisa do que você deseja que aconteça.

**Descreva as alternativas que você considerou**
Uma descrição clara e concisa de qualquer solução ou recurso alternativo que você tenha considerado.

**Contexto adicional**
Adicione qualquer outro contexto ou captura de tela sobre a solicitação de recurso aqui.
